//
//  prototypeInteractor.swift
//  Prueba
//
//  Created by Johnne Lemand on 07/12/23.
//

import Foundation


final class prototypeInteractor {
}

// MARK: - Extensions -

extension prototypeInteractor: prototypeInteractorInterface {
}
