//
//  DataCaptureInteractor.swift
//  Prueba
//
//  Created by Johnne Lemand on 10/12/23.
//

import Foundation

final class DataCaptureInteractor {
}

// MARK: - Extensions -

extension DataCaptureInteractor: DataCaptureInteractorInterface {
}
