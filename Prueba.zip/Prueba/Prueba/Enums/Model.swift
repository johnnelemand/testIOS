//
//  File.swift
//  Prueba
//
//  Created by Johnne Lemand on 08/12/23.
//
import UIKit

struct Option {
    var title: String
    var isSelected: Bool
}
