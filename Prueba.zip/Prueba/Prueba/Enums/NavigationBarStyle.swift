//
//  NavigationBarStyle.swift
//  Prueba
//
//  Created by Johnne Lemand on 07/12/23.
//

import Foundation

enum NavigationBarStyle {
    case blue
    case white
}
