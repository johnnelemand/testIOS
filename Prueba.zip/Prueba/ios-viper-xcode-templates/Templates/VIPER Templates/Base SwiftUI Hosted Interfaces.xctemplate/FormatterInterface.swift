//___FILEHEADER___

protocol FormatterInterface: AnyObject {
}

extension FormatterInterface {
}
