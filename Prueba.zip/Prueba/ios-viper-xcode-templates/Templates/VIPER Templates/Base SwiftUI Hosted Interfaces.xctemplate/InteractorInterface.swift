//___FILEHEADER___

protocol InteractorInterface: AnyObject {
}

extension InteractorInterface {
}
