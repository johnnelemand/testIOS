//___FILEHEADER___

protocol PresenterInterface: AnyObject {
}

extension PresenterInterface {
}
