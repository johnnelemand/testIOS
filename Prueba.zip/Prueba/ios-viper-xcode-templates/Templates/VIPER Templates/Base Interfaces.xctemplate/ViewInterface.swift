//___FILEHEADER___

protocol ViewInterface: AnyObject {
}

extension ViewInterface {
}
