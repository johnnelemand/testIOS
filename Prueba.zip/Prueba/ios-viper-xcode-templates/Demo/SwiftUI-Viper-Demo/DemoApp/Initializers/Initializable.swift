import Foundation

protocol Initializable {

    func initialize()

}
