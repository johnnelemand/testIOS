protocol PresenterInterface: AnyObject {
}

extension PresenterInterface {
}
