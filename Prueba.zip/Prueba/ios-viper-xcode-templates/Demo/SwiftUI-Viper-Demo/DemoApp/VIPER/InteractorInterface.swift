protocol InteractorInterface: AnyObject {
}

extension InteractorInterface {
}
