protocol FormatterInterface: AnyObject {
}

extension FormatterInterface {
}
