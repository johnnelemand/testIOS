import UIKit

protocol HomeWireframeInterface: WireframeInterface {
    func goBack()
}
