import Foundation

final class LoginInteractor {
}

// MARK: - Extensions -

extension LoginInteractor: LoginInteractorInterface {

    func login(with email: String) {
        // do something
    }

}
